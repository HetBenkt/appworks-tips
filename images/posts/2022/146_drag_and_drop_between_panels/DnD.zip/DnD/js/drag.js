$(document).ready(function () {
    let items = $('.container .box');
    items.each(function (item) {
        $(this).on('dragstart', handleDragStart);
        $(this).on('dragend', handleDragEnd);
    });

    function handleDragStart(e) {
        console.log('dragstart', e);
        this.style.opacity = '0.4';
        e.originalEvent.dataTransfer.setData('text/html', this.innerHTML);
    }

    function handleDragEnd(e) {
        console.log('dragend', e);
        this.style.opacity = '1';
    }
});