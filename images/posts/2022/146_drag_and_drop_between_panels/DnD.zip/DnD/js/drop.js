$(document).ready(function(){
    let items = $('.container .box');
    items.each(function (item) {
        $(this).on('drop', handlehandleDrop);
        $(this).on('dragover', handleDragOver);
        $(this).on('dragenter', handleDragEnter);
        $(this).on('dragleave', handleDragLeave);
    });

    function handlehandleDrop(e) {
        console.log('drop', e);
        e.originalEvent.stopPropagation(); // stops the browser from redirecting.
        this.innerHTML = e.originalEvent.dataTransfer.getData('text/html');

        // reset the current items
        items.each(function (key, item) {
            item.classList.remove('over');
        });

        return false;
    }

    function handleDragOver(e) {
        //console.log('dragover', e);
        e.originalEvent.preventDefault();
        return false;
    }

    function handleDragEnter(e) {
        console.log('dragenter', e);
		this.classList.add('over');
    }

    function handleDragLeave(e) {
		console.log('dragleave', e);
        this.classList.remove('over');
    }
});