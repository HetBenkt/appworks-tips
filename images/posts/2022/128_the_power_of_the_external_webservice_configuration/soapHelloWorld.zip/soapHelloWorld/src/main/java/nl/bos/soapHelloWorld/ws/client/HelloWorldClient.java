package nl.bos.soapHelloWorld.ws.client;

import nl.bos.types.helloworld.Message;
import nl.bos.types.helloworld.ObjectFactory;
import nl.bos.types.helloworld.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.core.WebServiceTemplate;

@Component
public class HelloWorldClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldClient.class);

    @Autowired
    private WebServiceTemplate webServiceTemplate;

    public String sayHello(String firstName, String lastName) {
        ObjectFactory factory = new ObjectFactory();
        User user = factory.createUser();

        user.setFirstName(firstName);
        user.setLastName(lastName);

        LOGGER.info("Client sending user[firstName={},lastName={}]", user.getFirstName(), user.getLastName());

        Message message = (Message) webServiceTemplate.marshalSendAndReceive(user);

        LOGGER.info("Client received message='{}'", message.getMessage());
        return message.getMessage();
    }
}
