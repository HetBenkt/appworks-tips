package nl.bos.soapHelloWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapHelloWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
