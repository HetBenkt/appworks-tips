package com.opentext.entity.eisconnector.helloworldeis;

import com.opentext.cordys.entityCore.connectors.genericEISConnector.definition.EISEntity;
import com.opentext.cordys.entityCore.connectors.genericEISConnector.definition.IEISDefinitionProvider;
import java.lang.String;
import java.util.List;
import java.util.Map;

public class HelloWorldEISEISDefinitionProvider implements IEISDefinitionProvider
{
  
	@Override
	public void init(Map<String,String> map1) {
 		 //TODO Auto-generated method
	}

	@Override
	public EISEntity getEntity(String string1) {
 		 //TODO Auto-generated method
		return null;
	}

	@Override
	public List<EISEntity> getEntities() {
 		 //TODO Auto-generated method
		return null;
	}
}
