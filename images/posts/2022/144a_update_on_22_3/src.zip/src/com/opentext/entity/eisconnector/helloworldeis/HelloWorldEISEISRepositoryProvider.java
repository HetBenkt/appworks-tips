package com.opentext.entity.eisconnector.helloworldeis;

import com.opentext.cordys.entityCore.connectors.genericEISConnector.definition.EISEntityProperty;
import com.opentext.cordys.entityCore.connectors.genericEISConnector.repository.EISContext;
import com.opentext.cordys.entityCore.connectors.genericEISConnector.repository.EISEntityRow;
import com.opentext.cordys.entityCore.connectors.genericEISConnector.repository.EISEntityRowColumn;
import com.opentext.cordys.entityCore.connectors.genericEISConnector.repository.EISRepositoryEntity;
import com.opentext.cordys.entityCore.connectors.genericEISConnector.repository.IEISRepositoryProvider;
import com.opentext.cordys.entityCore.connectors.genericEISConnector.repository.QueryWrapper;
import java.lang.Long;
import java.lang.Object;
import java.lang.String;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HelloWorldEISEISRepositoryProvider implements IEISRepositoryProvider
{
  
	@Override
	public EISEntityRow get(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, EISEntityRow eisEntityRow3) {
 		 //TODO Auto-generated method
		return null;
	}

	@Override
	public boolean update(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, EISEntityRow eisEntityRow3) {
 		 //TODO Auto-generated method
		return false;
	}

	@Override
	public void init(Map<String,String> map1) {
 		 //TODO Auto-generated method

 	 String baseUrl = map1.get("BaseURL"); 

 	 if (baseUrl != null && !baseUrl.isEmpty()) { 

 		 com.appworkstips.prjawtipsgen.HelloWorldEIS.invokers.Configuration.getDefaultApiClient().setBasePath(baseUrl);

 	 }
	}

	@Override
	public boolean delete(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, List<EISEntityRow> list3) {
 		 //TODO Auto-generated method
		return false;
	}

	@Override
	public EISEntityRow create(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, EISEntityRow eisEntityRow3) {
 		 //TODO Auto-generated method
		return null;
	}

	@Override
	public List<EISEntityRow> doQuery(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, QueryWrapper queryWrapper3) {
 		 //TODO Auto-generated method
		return null;
	}

	@Override
	public Long getTotalRecordCount(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, QueryWrapper queryWrapper3) {
 		 //TODO Auto-generated method
		return null;
	}

	@Override
	public List<EISEntityRow> genericEISListdoQuery(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, QueryWrapper queryWrapper3) {
 		 //TODO Auto-generated method

 	 Object returnObj = null;

 	 EISEntityRow row = null;

 	 List<EISEntityRow> rows = new ArrayList<EISEntityRow>();

 	 try {

 	 Class<?> modelAPI = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.apis."+eisRepositoryEntity2.getApiName());

 	 Object obj = modelAPI.getConstructor(null).newInstance(null);

 	 Method method = modelAPI.getDeclaredMethod(eisRepositoryEntity2.getMethodName());

 	 returnObj = method.invoke(obj);

 	 ArrayList list = (ArrayList) returnObj;

 	 for (Object obje : list) {

 		 Class<?> responseObjet = obje.getClass();

 			 Field[] fields = obje.getClass().getDeclaredFields();

 	 List<EISEntityRowColumn> rowColumns = new ArrayList<EISEntityRowColumn>();

 			 for (EISEntityProperty eisEntityProperty : eisRepositoryEntity2.getProperies()) {

 				 for (Field field : fields) {

 				 if (field.getName().equals(eisEntityProperty.isSetRefName() ? eisEntityProperty.getName().split("_"+eisEntityProperty.getRefId())[0]:eisEntityProperty.getName())) { 

 					 field.setAccessible(true);

 					 Class<?> childModel = null;

 					 if(eisEntityProperty.isSetRefName()) {

 						 childModel = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.models." +eisEntityProperty.getRefName()); 

 					 } 

 					 EISEntityRowColumn rowColumn = new EISEntityRowColumn();

 					 rowColumn.setColumnName(eisEntityProperty.getName());

 					 if (field.get(obje) == null) { 

 					 rowColumn.setColumnValue(null); 

 					 } else if (field.getType().equals(Integer.class) || field.getType().equals(Long.class)) {

 					 String strValue = field.get(obje).toString();

 					 rowColumn.setColumnValue(Integer.parseInt(strValue));

 					 } 

 					 else if (field.getType().equals(BigDecimal.class)) { 

 					 BigDecimal decimalValue = (BigDecimal) field.get(obje); 

 					 rowColumn.setColumnValue(decimalValue.intValue()); 

 					 } else if (field.getType().equals(Float.class)) { 

 					 float floatValue = (float) field.get(obje); 

 					 rowColumn.setColumnValue(floatValue); 

 					 } else if (field.getType().equals(Double.class)) { 

 					 Double doubleValue = (Double) field.get(obje); 

 					 String doubleValueStr = String.valueOf(doubleValue ); 

 					 float floatValue = Float.parseFloat(doubleValueStr); 

 					 rowColumn.setColumnValue(floatValue); 

 					 } 

 					 else if (field.getType().equals(Boolean.class)) { 

 						rowColumn.setColumnValue(field.get(obje)); 

 					 } 

 					 else if (field.getType().equals(Date.class)) {

 					 		Date date = (Date) field.get(obje);

 					 		rowColumn.setColumnValue(date);

 					 }

 					 else if (field.getType().equals(childModel)) {

 						 Object child = field.get(obje);

 						 Field[] subFields = field.getType().getDeclaredFields();

 						 for (Field subField : subFields) {

 							 subField.setAccessible(true);

 							 String refColumnName = eisEntityProperty.getRefName().toLowerCase()+"_";

 							 if(subField.getName().equalsIgnoreCase(rowColumn.getColumnName().split(refColumnName)[1])) {

 								 if (subField.getType().equals(Integer.class) || subField.getType().equals(Long.class)) {

 									 String strValue = subField.get(child).toString();

 									 rowColumn.setColumnValue(Integer.parseInt(strValue));

 								 } else if (field.getType().equals(BigDecimal.class)) {

 									 BigDecimal decimalValue = (BigDecimal) subField.get(child);

 									 rowColumn.setColumnValue(decimalValue.intValue());

 								 } else if (field.getType().equals(Float.class)) {

 									 float floatValue = (float) subField.get(child);

 									 rowColumn.setColumnValue(floatValue);

 								 } else if (field.getType().equals(Double.class)) {

 									 Double doubleValue = (Double) subField.get(child);

 									 String doubleValueStr = String.valueOf(doubleValue);

 									 float floatValue = Float.parseFloat(doubleValueStr);

 									 rowColumn.setColumnValue(floatValue);

 								 } else if (field.getType().equals(Boolean.class)) {

 									 rowColumn.setColumnValue(subField.get(child));

 								 } else if (field.getType().equals(Date.class)) {

 									 Date date = (Date) subField.get(child);

 									 rowColumn.setColumnValue(date);

 								 }

 							 }

 						 }

 					 }

 					 else { 

 					 String strValue = field.get(obje).toString();

 					 rowColumn.setColumnValue(strValue);

 					 			}

 					 rowColumns.add(rowColumn);

 					 }

 					 	}

 					 	}

 	 row = new EISEntityRow(); 

 	 row.setId(null); 

 	 row.setColumns(rowColumns);

 	 rows.add(row); 

 	 }

 	 return rows; 

 	 } catch (Exception exception) {

 		 throw new RuntimeException(exception);

 	}
	}

	@Override
	public EISEntityRow genericEISGet(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, EISEntityRow eisEntityRow3) {
 		 //TODO Auto-generated method

 	 Object obje = null;

 	 EISEntityRow row = null;

 	 try {

 	 Class<?> modelAPI = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.apis."+eisRepositoryEntity2.getApiName());

 	 Class[] parameterTypes = null;

 	 Object[] parameterObject = new Object[] {};

 	 Method[] modelAPIMethods = modelAPI.getDeclaredMethods();

 	 for (Method methodObj : modelAPIMethods) {

 	 	 if (methodObj.getName().equals(eisRepositoryEntity2.getMethodName())) {

 	 	 	 parameterTypes = methodObj.getParameterTypes(); 

 	 	 for (Class parameterType : parameterTypes) { 

 	 	 	 List<EISEntityRowColumn> eisEntityRowColumns = eisEntityRow3.getColumns();

 	 	 	 for(int i = 0; i<eisEntityRowColumns.size();i++) {

 	 	 	 if (parameterType.equals(Long.class)) { 

 	 	 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 	 	 temp.add(Long.parseLong(eisEntityRow3.getColumns().get(0).getColumnValue().toString()));

 	 	 	 	 parameterObject = temp.toArray();

 	 	 	 }

 	 	 if (parameterType.equals(Integer.class)) { 

 	 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 	 temp.add(Integer.parseInt(eisEntityRowColumns.get(i).getColumnValue().toString()));

 	 	 	 parameterObject = temp.toArray();

 	 	 }

 	 	 if (parameterType.equals(Float.class)) { 

 	 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 	 temp.add(Float.parseFloat(eisEntityRowColumns.get(i).getColumnValue().toString()));

 	 	  	 parameterObject = temp.toArray();

 	 	  }

 	 	 if (parameterType.equals(Double.class)) { 

 	 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 	 temp.add(Double.parseDouble(eisEntityRowColumns.get(i).getColumnValue().toString()));

 	 	 	 parameterObject = temp.toArray();

 	 	 }

 	 	 if (parameterType.equals(String.class)) { 

 	 	  ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 temp.add(eisEntityRowColumns.get(i).getColumnValue().toString());

 	 	 parameterObject = temp.toArray(); 

 	 	  }

 	 	 if (parameterType.equals(Boolean.class)) { 

 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 temp.add(eisEntityRowColumns.get(i).getColumnValue());

 	 	 parameterObject = temp.toArray();

 	 	 }

 	 	 }

 	 	 }

 	 	 }

 	 }

 	 Object obj = modelAPI.getConstructor(null).newInstance(null);

 	 Method method = modelAPI.getDeclaredMethod(eisRepositoryEntity2.getMethodName(), parameterTypes);

 	 obje = method.invoke(obj, parameterObject);

 		 Class<?> responseObjet = obje.getClass();

 			 Field[] fields = obje.getClass().getDeclaredFields();

 	 List<EISEntityRowColumn> rowColumns = new ArrayList<EISEntityRowColumn>();

 			 for (EISEntityProperty eisEntityProperty : eisRepositoryEntity2.getProperies()) {

 				 for (Field field : fields) {

 				 if (field.getName().equals(eisEntityProperty.isSetRefName() ? eisEntityProperty.getName().split("_"+eisEntityProperty.getRefId())[0]:eisEntityProperty.getName())) { 

 					 field.setAccessible(true);

 					 Class<?> childModel = null;

 					 if(eisEntityProperty.isSetRefName()) {

 						 childModel = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.models." +eisEntityProperty.getRefName()); 

 					 } 

 					 EISEntityRowColumn rowColumn = new EISEntityRowColumn();

 					 rowColumn.setColumnName(eisEntityProperty.getName());

 					 if (field.get(obje) == null) { 

 					 rowColumn.setColumnValue(null); 

 					 } else if (field.getType().equals(Integer.class) || field.getType().equals(Long.class)) {

 					 String strValue = field.get(obje).toString();

 					 rowColumn.setColumnValue(Integer.parseInt(strValue));

 					 } 

 					 else if (field.getType().equals(BigDecimal.class)) { 

 					 BigDecimal decimalValue = (BigDecimal) field.get(obje); 

 					 rowColumn.setColumnValue(decimalValue.intValue()); 

 					 } else if (field.getType().equals(Float.class)) { 

 					 float floatValue = (float) field.get(obje); 

 					 rowColumn.setColumnValue(floatValue); 

 					 } else if (field.getType().equals(Double.class)) { 

 					 Double doubleValue = (Double) field.get(obje); 

 					 String doubleValueStr = String.valueOf(doubleValue ); 

 					 float floatValue = Float.parseFloat(doubleValueStr); 

 					 rowColumn.setColumnValue(floatValue); 

 					 } 

 					 else if (field.getType().equals(Boolean.class)) { 

 						rowColumn.setColumnValue(field.get(obje)); 

 					 } 

 					 else if (field.getType().equals(Date.class)) {

 					 		Date date = (Date) field.get(obje);

 					 		rowColumn.setColumnValue(date);

 					 }

 					 else if (field.getType().equals(childModel)) {

 						 Object child = field.get(obje);

 						 Field[] subFields = field.getType().getDeclaredFields();

 						 for (Field subField : subFields) {

 							 subField.setAccessible(true);

 							 String refColumnName = eisEntityProperty.getRefName().toLowerCase()+"_";

 							 if(subField.getName().equalsIgnoreCase(rowColumn.getColumnName().split(refColumnName)[1])) {

 								 if (subField.getType().equals(Integer.class) || subField.getType().equals(Long.class)) {

 									 String strValue = subField.get(child).toString();

 									 rowColumn.setColumnValue(Integer.parseInt(strValue));

 								 } else if (field.getType().equals(BigDecimal.class)) {

 									 BigDecimal decimalValue = (BigDecimal) subField.get(child);

 									 rowColumn.setColumnValue(decimalValue.intValue());

 								 } else if (field.getType().equals(Float.class)) {

 									 float floatValue = (float) subField.get(child);

 									 rowColumn.setColumnValue(floatValue);

 								 } else if (field.getType().equals(Double.class)) {

 									 Double doubleValue = (Double) subField.get(child);

 									 String doubleValueStr = String.valueOf(doubleValue);

 									 float floatValue = Float.parseFloat(doubleValueStr);

 									 rowColumn.setColumnValue(floatValue);

 								 } else if (field.getType().equals(Boolean.class)) {

 									 rowColumn.setColumnValue(subField.get(child));

 								 } else if (field.getType().equals(Date.class)) {

 									 Date date = (Date) subField.get(child);

 									 rowColumn.setColumnValue(date);

 								 }

 							 }

 						 }

 					 }

 					 else { 

 					 String strValue = field.get(obje).toString();

 					 rowColumn.setColumnValue(strValue);

 					 			}

 					 rowColumns.add(rowColumn);

 					 }

 					 	}

 	 row = new EISEntityRow(); 

 	 row.setId(null); 

 	 row.setColumns(rowColumns);

 	 }

 	 return row; 

 	 } catch (Exception exception) {

 		 throw new RuntimeException(exception);

 	}
	}

	@Override
	public EISEntityRow genericEISCreate(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, EISEntityRow eisEntityRow3) {
 		 //TODO Auto-generated method

 	 Object obje = null; 

 	 EISEntityRow row = null; 

 	 try {

 		 Class<?> modelAPI = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.apis."+eisRepositoryEntity2.getApiName());

 		 Object obj = modelAPI.getConstructor(null).newInstance(null);

 		 Class<?> model = Class
					.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.models." + eisRepositoryEntity2.getModelName());

 		 Object instance = model.getConstructor(null).newInstance(null); 

 		 Field[] fields1 = instance.getClass().getDeclaredFields(); 

 		 Map<String, Object> rowMap = new HashMap<>(); 

 		 for (EISEntityRowColumn eISEntityRowColumn : eisEntityRow3.getColumns()) { 

 			 rowMap.put(eISEntityRowColumn.getColumnName(), eISEntityRowColumn.getColumnValue()); 

 		 } 

 		 for (EISEntityProperty eisEntityProperty : eisRepositoryEntity2.getProperies()) { 

 			 for (Field field : fields1) { 

 				 if (field.getName().equals(eisEntityProperty.isSetRefName() ? eisEntityProperty.getName().split("_"+eisEntityProperty.getRefId())[0]:eisEntityProperty.getName())) { 

 					 field.setAccessible(true); 

 					 Class<?> childModel = null;

 					 if(eisEntityProperty.isSetRefName()) {

 						 childModel = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.models." +eisEntityProperty.getRefName()); 

 					 } 

 					 if (field.getType().equals(Integer.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? Integer.parseInt(rowMap.get(field.getName()).toString()) : null); 

 					 } else if (field.getType().equals(Long.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? ((Integer) rowMap.get(field.getName())).longValue() : null); 

 					 } else if (field.getType().equals(BigDecimal.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? new BigDecimal(rowMap.get(field.getName()).toString()) : null); 

 					 } else if (field.getType().equals(Float.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? Float.parseFloat(rowMap.get(field.getName()).toString()) : null); 

 					 } else if (field.getType().equals(Double.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? Double.parseDouble(rowMap.get(field.getName()).toString()) : null); 

 					 } else if (field.getType().equals(Boolean.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? rowMap.get(field.getName()) : false); 

 					 } else if (field.getType().equals(childModel)) {  

 						 Object childInstance = childModel.getConstructor(null).newInstance(null);  

 						 childInstance = getChildObject(childInstance, field, rowMap, eisEntityProperty);  

 						 field.set(instance, childInstance);  

 					 } else { 

 						 field.set(instance, rowMap.get(field.getName())); 

 					 } 

 				 } 

 			 } 

 		 } 

 		 Method method = modelAPI.getDeclaredMethod(eisRepositoryEntity2.getMethodName(), instance.getClass()); 

 		 obje = method.invoke(obj, instance); 

 		 Class<?> responseObjet = obje.getClass();

 			 Field[] fields = obje.getClass().getDeclaredFields();

 	 List<EISEntityRowColumn> rowColumns = new ArrayList<EISEntityRowColumn>();

 			 for (EISEntityProperty eisEntityProperty : eisRepositoryEntity2.getProperies()) {

 				 for (Field field : fields) {

 				 if (field.getName().equals(eisEntityProperty.isSetRefName() ? eisEntityProperty.getName().split("_"+eisEntityProperty.getRefId())[0]:eisEntityProperty.getName())) { 

 					 field.setAccessible(true);

 					 Class<?> childModel = null;

 					 if(eisEntityProperty.isSetRefName()) {

 						 childModel = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.models." +eisEntityProperty.getRefName()); 

 					 } 

 					 EISEntityRowColumn rowColumn = new EISEntityRowColumn();

 					 rowColumn.setColumnName(eisEntityProperty.getName());

 					 if (field.get(obje) == null) { 

 					 rowColumn.setColumnValue(null); 

 					 } else if (field.getType().equals(Integer.class) || field.getType().equals(Long.class)) {

 					 String strValue = field.get(obje).toString();

 					 rowColumn.setColumnValue(Integer.parseInt(strValue));

 					 } 

 					 else if (field.getType().equals(BigDecimal.class)) { 

 					 BigDecimal decimalValue = (BigDecimal) field.get(obje); 

 					 rowColumn.setColumnValue(decimalValue.intValue()); 

 					 } else if (field.getType().equals(Float.class)) { 

 					 float floatValue = (float) field.get(obje); 

 					 rowColumn.setColumnValue(floatValue); 

 					 } else if (field.getType().equals(Double.class)) { 

 					 Double doubleValue = (Double) field.get(obje); 

 					 String doubleValueStr = String.valueOf(doubleValue ); 

 					 float floatValue = Float.parseFloat(doubleValueStr); 

 					 rowColumn.setColumnValue(floatValue); 

 					 } 

 					 else if (field.getType().equals(Boolean.class)) { 

 						rowColumn.setColumnValue(field.get(obje)); 

 					 } 

 					 else if (field.getType().equals(Date.class)) {

 					 		Date date = (Date) field.get(obje);

 					 		rowColumn.setColumnValue(date);

 					 }

 					 else if (field.getType().equals(childModel)) {

 						 Object child = field.get(obje);

 						 Field[] subFields = field.getType().getDeclaredFields();

 						 for (Field subField : subFields) {

 							 subField.setAccessible(true);

 							 String refColumnName = eisEntityProperty.getRefName().toLowerCase()+"_";

 							 if(subField.getName().equalsIgnoreCase(rowColumn.getColumnName().split(refColumnName)[1])) {

 								 if (subField.getType().equals(Integer.class) || subField.getType().equals(Long.class)) {

 									 String strValue = subField.get(child).toString();

 									 rowColumn.setColumnValue(Integer.parseInt(strValue));

 								 } else if (field.getType().equals(BigDecimal.class)) {

 									 BigDecimal decimalValue = (BigDecimal) subField.get(child);

 									 rowColumn.setColumnValue(decimalValue.intValue());

 								 } else if (field.getType().equals(Float.class)) {

 									 float floatValue = (float) subField.get(child);

 									 rowColumn.setColumnValue(floatValue);

 								 } else if (field.getType().equals(Double.class)) {

 									 Double doubleValue = (Double) subField.get(child);

 									 String doubleValueStr = String.valueOf(doubleValue);

 									 float floatValue = Float.parseFloat(doubleValueStr);

 									 rowColumn.setColumnValue(floatValue);

 								 } else if (field.getType().equals(Boolean.class)) {

 									 rowColumn.setColumnValue(subField.get(child));

 								 } else if (field.getType().equals(Date.class)) {

 									 Date date = (Date) subField.get(child);

 									 rowColumn.setColumnValue(date);

 								 }

 							 }

 						 }

 					 }

 					 else { 

 					 String strValue = field.get(obje).toString();

 					 rowColumn.setColumnValue(strValue);

 					 			}

 					 rowColumns.add(rowColumn);

 					 }

 					 	}

 	 row = new EISEntityRow(); 

 	 row.setId(null); 

 	 row.setColumns(rowColumns);

 	 }

 	 return row; 

 		 } catch (Exception exception) { 

 			 throw new RuntimeException(exception); 

 		 } 
	}

	@Override
	public boolean genericEISDelete(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, List<EISEntityRow> list3) {
 		 //TODO Auto-generated method

 	 Object obje = null;

 	 EISEntityRow row = null;

 	 try {

 	 Class<?> modelAPI = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.apis."+eisRepositoryEntity2.getApiName());

 	 Class[] parameterTypes = null;

 	 Object[] parameterObject = new Object[] {};

 	 Method[] modelAPIMethods = modelAPI.getDeclaredMethods();

 	 for (Method methodObj : modelAPIMethods) {

 	 	 if (methodObj.getName().equals(eisRepositoryEntity2.getMethodName())) {

 	 	 	 parameterTypes = methodObj.getParameterTypes(); 

 	 	 for (Class parameterType : parameterTypes) { 

 	 	 	 List<EISEntityRowColumn> eisEntityRowColumns = list3.get(0).getColumns();

 	 	 	 for(int i = 0; i<eisEntityRowColumns.size();i++) {

 	 	 	 if (parameterType.equals(Long.class)) { 

 	 	 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 	 	 temp.add(Long.parseLong(list3.get(0).getColumns().get(0).getColumnValue().toString()));

 	 	 	 	 parameterObject = temp.toArray();

 	 	 	 }

 	 	 if (parameterType.equals(Integer.class)) { 

 	 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 	 temp.add(Integer.parseInt(eisEntityRowColumns.get(i).getColumnValue().toString()));

 	 	 	 parameterObject = temp.toArray();

 	 	 }

 	 	 if (parameterType.equals(Float.class)) { 

 	 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 	 temp.add(Float.parseFloat(eisEntityRowColumns.get(i).getColumnValue().toString()));

 	 	  	 parameterObject = temp.toArray();

 	 	  }

 	 	 if (parameterType.equals(Double.class)) { 

 	 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 	 temp.add(Double.parseDouble(eisEntityRowColumns.get(i).getColumnValue().toString()));

 	 	 	 parameterObject = temp.toArray();

 	 	 }

 	 	 if (parameterType.equals(String.class)) { 

 	 	  ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 temp.add(eisEntityRowColumns.get(i).getColumnValue().toString());

 	 	 parameterObject = temp.toArray(); 

 	 	  }

 	 	 if (parameterType.equals(Boolean.class)) { 

 	 	 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 	 	 temp.add(eisEntityRowColumns.get(i).getColumnValue());

 	 	 parameterObject = temp.toArray();

 	 	 }

 	 	 }

 	 	 }

 	 	 }

 	 }

 	 Object obj = modelAPI.getConstructor(null).newInstance(null);

 	 Method method = modelAPI.getDeclaredMethod(eisRepositoryEntity2.getMethodName(), parameterTypes);

 	 obje = method.invoke(obj, parameterObject);

 	 return true; 

 	 } catch (Exception exception) {

 		 throw new RuntimeException(exception); 

 	}
	}

	@Override
	public boolean genericEISUpdate(EISContext eisContext1, EISRepositoryEntity eisRepositoryEntity2, EISEntityRow eisEntityRow3, EISEntityRow eisEntityRow4) {
 		 //TODO Auto-generated method

 	 try {

 		 Class<?> modelAPI = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.apis."+eisRepositoryEntity2.getApiName());

 		 Object obj = modelAPI.getConstructor(null).newInstance(null);

 		 Class<?> model = Class
					.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.models." + eisRepositoryEntity2.getModelName());

 		 Object instance = model.getConstructor(null).newInstance(null); 

 		 Field[] fields = instance.getClass().getDeclaredFields(); 

 		 Map<String, Object> rowMap = new HashMap<>(); 

 		 for (EISEntityRowColumn eISEntityRowColumn : eisEntityRow3.getColumns()) { 

 			 rowMap.put(eISEntityRowColumn.getColumnName(), eISEntityRowColumn.getColumnValue()); 

 		 } 

 		 for (EISEntityProperty eisEntityProperty : eisRepositoryEntity2.getProperies()) { 

 			 for (Field field : fields) { 

 				 if (field.getName().equals(eisEntityProperty.isSetRefName() ? eisEntityProperty.getName().split("_"+eisEntityProperty.getRefId())[0]:eisEntityProperty.getName())) { 

 					 field.setAccessible(true); 

 					 Class<?> childModel = null;

 					 if(eisEntityProperty.isSetRefName()) {

 						 childModel = Class.forName("com.appworkstips.prjawtipsgen.HelloWorldEIS.models." +eisEntityProperty.getRefName()); 

 					 } 

 					 if (field.getType().equals(Integer.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? Integer.parseInt(rowMap.get(field.getName()).toString()) : null); 

 					 } else if (field.getType().equals(Long.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? ((Integer) rowMap.get(field.getName())).longValue() : null); 

 					 } else if (field.getType().equals(BigDecimal.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? new BigDecimal(rowMap.get(field.getName()).toString()) : null); 

 					 } else if (field.getType().equals(Float.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? Float.parseFloat(rowMap.get(field.getName()).toString()) : null); 

 					 } else if (field.getType().equals(Double.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? Double.parseDouble(rowMap.get(field.getName()).toString()) : null); 

 					 } else if (field.getType().equals(Boolean.class)) { 

 						 field.set(instance, rowMap.get(field.getName()) != null ? rowMap.get(field.getName()) : false); 

 					 } else if (field.getType().equals(childModel)) {  

 						 Object childInstance = childModel.getConstructor(null).newInstance(null);  

 						 childInstance = getChildObject(childInstance, field, rowMap, eisEntityProperty);  

 						 field.set(instance, childInstance);  

 					 } else { 

 						 field.set(instance, rowMap.get(field.getName())); 

 					 } 

 				 } 

 			 } 

 		 } 

 		 Class[] parameterTypes = null;

 		 Object[] parameterObject = new Object[] {};

 		 ArrayList<Object> temp1 = new ArrayList<Object>(Arrays.asList(parameterObject));

 		 temp1.add(instance);

 		 parameterObject = temp1.toArray();

 		 Method[] modelAPIMethods = modelAPI.getDeclaredMethods();

 		 for (Method methodObj : modelAPIMethods) {

 		 if (methodObj.getName().equals(eisRepositoryEntity2.getMethodName())) {

 		 parameterTypes = methodObj.getParameterTypes();

 		 }

 		 }

 		 Method method = modelAPI.getDeclaredMethod(eisRepositoryEntity2.getMethodName(), parameterTypes);

 		 if (method.getName().equals(eisRepositoryEntity2.getMethodName())) {

 		 for (Class parameterType : parameterTypes) {

 		 List<EISEntityRowColumn> eisEntityRowColumns = eisEntityRow4.getColumns();

 		 for (int i = 0; i < eisEntityRowColumns.size(); i++) {

 		 if (parameterType.equals(Long.class)) {

 		 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 		 temp.add(Long.parseLong(eisEntityRowColumns.get(0).getColumnValue().toString()));

 		 parameterObject = temp.toArray();

 		 }

 		 if (parameterType.equals(Integer.class)) { 

 		 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 		 temp.add(Integer.parseInt(eisEntityRowColumns.get(i).getColumnValue().toString()));

 		 parameterObject = temp.toArray();

 		 }

 		 if (parameterType.equals(Float.class)) {

 		 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 		 temp.add(Float.parseFloat(eisEntityRowColumns.get(i).getColumnValue().toString()));

 		 parameterObject = temp.toArray();

 		 }

 		 if (parameterType.equals(Double.class)) { 

 		 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 		  temp.add(Double.parseDouble(eisEntityRowColumns.get(i).getColumnValue().toString()));

 		  parameterObject = temp.toArray();

 		  }

 		 if (parameterType.equals(String.class)) { 

 		  ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 		 temp.add(eisEntityRowColumns.get(i).getColumnValue().toString());

 		 parameterObject = temp.toArray(); 

 		  }

 		  if (parameterType.equals(Boolean.class)) { 

 		 ArrayList<Object> temp = new ArrayList<Object>(Arrays.asList(parameterObject));

 		  temp.add(eisEntityRowColumns.get(i).getColumnValue());

 		  parameterObject = temp.toArray();

 		  }

 		 }

 		 }

 		 }

 		 method.invoke(obj, parameterObject); 

 	 return true; 

 		 } catch (Exception exception) { 

 			 throw new RuntimeException(exception); 

 		 } 
	}

	@Override
	public Object getChildObject(Object object1, Field field2, Map<String,Object> map3, EISEntityProperty eisEntityProperty4) {
 		 //TODO Auto-generated method

 	 try { 

 		 Field[] childFields = object1.getClass().getDeclaredFields(); 

 		 EISEntityRow eISEntityChildRow = (EISEntityRow) map3.get(eisEntityProperty4.getName()); 

 		 for (EISEntityRowColumn eISEntityChildRowColumn : eISEntityChildRow.getColumns()) { 

 			 for (Field childField : childFields) { 

 				 childField.setAccessible(true); 

 				 if (childField.getName().equalsIgnoreCase(eISEntityChildRowColumn.getColumnName())) { 

 					 if (childField.getType().equals(Integer.class)) { 

 						 childField.set(object1, eISEntityChildRowColumn.getColumnValue() != null ?  Integer.parseInt(eISEntityChildRowColumn.getColumnValue().toString()) : null); 

 					 } else if (childField.getType().equals(Long.class)) { 

 						 childField.set(object1, eISEntityChildRowColumn.getColumnValue() != null ? ((Integer) eISEntityChildRowColumn.getColumnValue()).longValue() : null); 

 					 } else if (childField.getType().equals(BigDecimal.class)) { 

 						 childField.set(object1, eISEntityChildRowColumn.getColumnValue() != null ? new BigDecimal(eISEntityChildRowColumn.getColumnValue().toString()) : null); 

 					 } else if (childField.getType().equals(Float.class)) { 

 						 childField.set(object1, eISEntityChildRowColumn.getColumnValue() != null ? Float.parseFloat(eISEntityChildRowColumn.getColumnValue().toString()) : null); 

 					 } else if (childField.getType().equals(Double.class)) { 

 						 childField.set(object1, eISEntityChildRowColumn.getColumnValue() != null ? Double.parseDouble(eISEntityChildRowColumn.getColumnValue().toString()) : null); 

 					 } else if (childField.getType().equals(Boolean.class)) { 

 						 childField.set(object1, eISEntityChildRowColumn.getColumnValue() != null ? eISEntityChildRowColumn.getColumnValue() : false); 

 					 } else { 

 						 childField.set(object1, eISEntityChildRowColumn.getColumnValue()); 

 					 } 

 				 } 

 			 } 

 		 } 

 		 return object1; 

 	 } catch (Exception exception) { 

 		 throw new RuntimeException(exception); 

 	 } 
	}

	@Override
	public boolean testConnection() {
 		 //TODO Auto-generated method
		return false;
	}
}
