google.charts.load('current', {'packages': ['gauge']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {

    $.cordys.ajax({
        method: "all_cases",
        namespace: "http://schemas/AppWorksTipsgeneric/case/operations",
        success: successFunction,
        error: errorFunction
    });

    function successFunction(response) {
        let data = new google.visualization.DataTable();
        data.addColumn('string', 'Label');
        data.addColumn('number', 'Value');
        let states = [];
        $.each(response, function (entry, metadata) {
            console.log("Response:", entry, metadata);
            if (entry.includes("case") && metadata.case_status === 'finalized') {
                states.push(metadata.case_status);
            }
        });

        let uniqueStates = states.filter((item, i, ar) => ar.indexOf(item) === i);
        for (let i = 0; i < uniqueStates.length; i++) {
            let count = states.filter(function (state) {
                if (state === uniqueStates[i]) {
                    return true;
                } else {
                    return false;
                }
            });
            data.addRow([uniqueStates[i], count.length]);
        }

        let options = {
            redFrom: 45, redTo: 50,
            yellowFrom: 30, yellowTo: 45,
            minorTicks: 5,
            max: 50,
            backgroundColor: '#000000'
        };

        let chart = new google.visualization.Gauge(document.getElementById('gauge'));

        chart.draw(data, options);
    }

    function errorFunction(error) {
        console.log("Error:", error);
    }
}