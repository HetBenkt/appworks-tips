google.charts.load('current', {'packages': ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {

    $.cordys.ajax({
        method: "all_cases",
        namespace: "http://schemas/AppWorksTipsgeneric/case/operations",
        success: successFunction,
        error: errorFunction
    });

    function successFunction(response) {
        let data = new google.visualization.DataTable();
        data.addColumn('string', 'Status');
        data.addColumn('number', 'In State');
        let states = [];
        $.each(response, function (entry, metadata) {
            console.log("Response:", entry, metadata);
            if (entry.includes("case")) {
                states.push(metadata.case_status);
            }
        });

        let uniqueStates = states.filter((item, i, ar) => ar.indexOf(item) === i);
        for (let i = 0; i < uniqueStates.length; i++) {
            let count = states.filter(function (state) {
                if (state === uniqueStates[i]) {
                    return true;
                } else {
                    return false;
                }
            });
            data.addRow([uniqueStates[i], count.length]);
        }

        let options = {
            title: 'Cases per state',
            titleTextStyle: {color: 'white'},
            backgroundColor: '#000000',
            legend: {position: "none"},
            hAxis: {
                textStyle: {color: '#FFF'}
            },
            vAxis: {
                textStyle: {color: '#FFF'}
            }
        };

        let chart = new google.visualization.ColumnChart(document.getElementById('columnchart'));

        chart.draw(data, options);
    }

    function errorFunction(error) {
        console.log("Error:", error);
    }
}