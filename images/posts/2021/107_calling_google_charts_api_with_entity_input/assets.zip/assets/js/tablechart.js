google.charts.load('current', {'packages': ['table']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {

    $.cordys.ajax({
        method: "all_cases",
        namespace: "http://schemas/AppWorksTipsgeneric/case/operations",
        success: successFunction,
        error: errorFunction
    });

    function successFunction(response) {
        let data = new google.visualization.DataTable();
        data.addColumn('string', 'Name');
        data.addColumn('string', 'Status');
        data.addColumn('boolean', 'Is Active');
        data.addColumn('number', 'Budget');
        data.addColumn('date', 'Date');

        $.each(response, function (entry, metadata) {
            console.log("Response:", entry, metadata);
            if (entry.includes("case")) {
                data.addRow([metadata.case_name, metadata.case_status, metadata.case_is_active == 'true', Number(metadata.case_budget), new Date(metadata.case_start_date)]);
            }
        });

        var cssClassNames = {
            'headerRow': 'cssHeaderRow',
            'tableRow': 'cssTableRow',
            'oddTableRow': 'cssOddTableRow',
            'selectedTableRow': 'cssSelectedTableRow',
            'hoverTableRow': 'cssHoverTableRow',
            'headerCell': 'cssHeaderCell',
            'tableCell': 'cssTableCell',
            'rowNumberCell': 'cssRowNumberCell'
        };

        let options = {
            showRowNumber: true,
            width: '100%',
            height: '100%',
            cssClassNames: cssClassNames
        };

        let chart = new google.visualization.Table(document.getElementById('tablechart'));

        chart.draw(data, options);
    }

    function errorFunction(error) {
        console.log("Error:", error);
    }
}