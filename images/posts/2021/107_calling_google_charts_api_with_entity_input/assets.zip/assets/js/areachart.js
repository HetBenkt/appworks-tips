google.charts.load('current', {'packages': ['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {

    $.cordys.ajax({
        method: "all_cases",
        namespace: "http://schemas/AppWorksTipsgeneric/case/operations",
        success: successFunction,
        error: errorFunction
    });

    function successFunction(response) {
        let data = new google.visualization.DataTable();
        data.addColumn('string', 'Year');
        data.addColumn('number', 'Budget');
        $.each(response, function (entry, metadata) {
            console.log("Response:", entry, metadata);
            if (entry.includes("case")) {
                data.addRow(['' + new Date(metadata.case_start_date).getFullYear(), Number(metadata.case_budget)]);
            }
        });

        let options = {
            title: 'Case performance',
            titleTextStyle: {color: 'white'},
            hAxis: {title: 'Year', titleTextStyle: {color: '#FFF'}, textStyle: {color: '#FFF'}},
            vAxis: {minValue: 0, textStyle: {color: '#FFF'}},
            backgroundColor: '#000000',
            legend: "none"
        };

        let chart = new google.visualization.AreaChart(document.getElementById('areachart'));

        chart.draw(data, options);
    }

    function errorFunction(error) {
        console.log("Error:", error);
    }
}