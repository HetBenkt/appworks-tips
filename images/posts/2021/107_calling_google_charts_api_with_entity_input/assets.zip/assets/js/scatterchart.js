google.charts.load('current', {'packages': ['corechart']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {

    $.cordys.ajax({
        method: "all_cases",
        namespace: "http://schemas/AppWorksTipsgeneric/case/operations",
        success: successFunction,
        error: errorFunction
    });

    function successFunction(response) {
        let data = new google.visualization.DataTable();
        data.addColumn('number', 'Year');
        data.addColumn('number', 'Budget');
        $.each(response, function (entry, metadata) {
            console.log("Response:", entry, metadata);
            if (entry.includes("case")) {
                data.addRow([new Date(metadata.case_start_date).getFullYear(), Number(metadata.case_budget)]);
            }
        });

        let options = {
            title: 'Year vs. Budget comparison',
            titleTextStyle: {color: 'white'},
            hAxis: {title: 'Year', titleTextStyle: {color: '#FFF'}, textStyle: {color: '#FFF'}},
            vAxis: {title: 'Budget', titleTextStyle: {color: '#FFF'}, minValue: 0, textStyle: {color: '#FFF'}},
            backgroundColor: '#000000',
            legend: "none",
            trendlines: { 0: { color: 'green'}}
        };

        let chart = new google.visualization.ScatterChart(document.getElementById('scatterchart'));

        chart.draw(data, options);
    }

    function errorFunction(error) {
        console.log("Error:", error);
    }
}