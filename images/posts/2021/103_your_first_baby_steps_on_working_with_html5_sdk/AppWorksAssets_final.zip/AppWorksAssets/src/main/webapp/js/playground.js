$(document).ready(function () {
    console.log('Hello world...');

    $.urlParam = function (name) {
        var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results == null) {
            return null;
        } else {
            return results[1] || 0;
        }
    }
    let itemId = decodeURIComponent($.urlParam('itemid'));
    console.log("itemId:", itemId);

    $.cordys.ajax({
        method: "Readperson",
        namespace: "http://schemas/AppWorksTipsproj_gen/person/operations",
        parameters: {
            "person-id": {
                ItemId: itemId
            }
        },
        success: successFunction,
        error: errorFunction
    });

    function successFunction(response) {
        console.log("Response: ", JSON.stringify(response));

        let persons = [];
        jQuery.each(response, function (entry, data) {
            if (entry.includes("person")) {
                persons.push({name: data.name, age: data.age});
            }
        });

        ko.applyBindings({
            persons
        });
    }

    function errorFunction(error) {
        console.log("Error: ", error);
    }
});