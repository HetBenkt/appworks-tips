package nl.bos.http;

import com.eibus.security.identity.Identity;
import com.eibus.util.logger.CordysLogger;
import com.opentext.applicationconnector.httpconnector.config.IParameter;
import com.opentext.applicationconnector.httpconnector.config.IServerConnection;
import com.opentext.applicationconnector.httpconnector.exception.HandlerException;
import com.opentext.applicationconnector.httpconnector.impl.HttpObject;
import com.opentext.applicationconnector.httpconnector.impl.RestRequestHandler;

import java.net.HttpURLConnection;
import java.util.Map;

public class MyRestRequestHandler extends RestRequestHandler {
    private static final CordysLogger LOG = CordysLogger.getCordysLogger(MyRestRequestHandler.class);

    @Override
    public HttpObject process(int requestNode, IServerConnection connection, Identity identity) throws HandlerException {
        if(LOG.isDebugEnabled()) {
            LOG.debug(String.format("MyRestRequestHandler.process() for user: %s", identity.getAuthenticatedUserCN()));
        }

        Map<String, IParameter> parameters = connection.getParameters();
        for (Map.Entry<String, IParameter> parameter : parameters.entrySet()) {
            if(LOG.isDebugEnabled()) {
                LOG.debug(String.format("key: %s; name: %s; value: %s", parameter.getKey(), parameter.getValue().getName(), parameter.getValue().getValue()));
            }
        }

        HttpObject process = super.process(requestNode, connection, identity);
        HttpURLConnection httpUrlConnection = process.getHttpUrlConnection();
        httpUrlConnection.setRequestProperty("Authorization", String.format("Bearer %s", "{BEARER_TOKEN}"));
        httpUrlConnection.setRequestProperty("Content-Type","application/json");

        return process;
    }
}