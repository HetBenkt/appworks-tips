$(document).ready(function() {

    $.cordys.ajax({
        method: "GetProcessInstanceSummary",
        namespace: "http://schemas.cordys.com/pim/queryinstancedata/1.0",
        parameters: {
            'Query': {
                'Select': {
                    'QueryableObject': 'InstancesSummary',
                    'Field': 'ProcessName'
                },
                'Filters': {
                    'In': {
                        '@field': 'STATUS',
                        'Value': ['ABORTED', 'WAITING', 'COMPLETE']
                    }
                }
            }
        },
        success: successFunction,
        error: errorFunction
    });

    function successFunction(response) {
        console.log("Response: ", JSON.stringify(response));

        const tuples = Array.isArray(response?.tuple) ? response.tuple : [response?.tuple];
        const gridData = tuples.map(tuple => {
            const instancesSummary = tuple?.old?.InstancesSummary || {};
            return [
                instancesSummary?.ProcessName || "N/A",
                instancesSummary?.Description || "N/A",
                instancesSummary?.NrTotal || "0",
                instancesSummary?.NrAborted || "0",
                instancesSummary?.NrComplete || "0",
                instancesSummary?.NrWaiting || "0"
            ];
        });

        new gridjs.Grid({
            columns: ["Process Name", "Description", "Nr Total", "Nr Aborted", "Nr Complete", "Nr Waiting"],
            sort: true,
            data: gridData
        }).render(document.getElementById("wrapper"));
    };

    function errorFunction(error) {
        console.log("Error: ", error);
    };

});