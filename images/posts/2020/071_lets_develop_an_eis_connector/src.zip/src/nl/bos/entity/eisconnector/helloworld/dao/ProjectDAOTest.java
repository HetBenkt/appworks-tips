package nl.bos.entity.eisconnector.helloworld.dao;

import org.junit.Assert;

import java.util.List;

public class ProjectDAOTest {

    @org.junit.Test
    public void save() {
        IDataAccessObject projectDAO = new ProjectDAO();
        projectDAO.save(new Project(1, "Dummy1"));
        projectDAO.save(new Project(2, "Dummy2"));
        projectDAO.save(new Project(3, "Dummy3"));
    }

    @org.junit.Test
    public void get() {
        IDataAccessObject projectDAO = new ProjectDAO();
        Project project = projectDAO.get(1);
        Assert.assertNotNull(project);
        Assert.assertEquals("Dummy1", project.getSubject());
    }

    @org.junit.Test
    public void update() {
        IDataAccessObject projectDAO = new ProjectDAO();
        Project project = projectDAO.get(1);
        project.setSubject("Updated Dummy1");
        projectDAO.update(1, project);
        Assert.assertEquals("Updated Dummy1", projectDAO.get(1).getSubject());
    }

    @org.junit.Test
    public void delete() {
        IDataAccessObject projectDAO = new ProjectDAO();
        projectDAO.delete(1);
        Assert.assertNull(projectDAO.get(1));
    }

    @org.junit.Test
    public void getAll() {
        IDataAccessObject projectDAO = new ProjectDAO();
        List<Project> projects = projectDAO.getAll();
        Assert.assertEquals(2, projects.size());
    }
}